
import './App.css';

function App() {
  return (
    <div className="App">
      <div className="header">
        <ul>
          <li>Trang chủ</li>
          <li>Contack</li>
          <li>Quần</li>
          <li>Áo</li>
          <li>Túi sách</li>
        </ul>
      </div>
      
    </div>
    
  );
}

export default App;
