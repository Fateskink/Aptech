package com.aptech.de01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class De01Application {

	public static void main(String[] args) {
		SpringApplication.run(De01Application.class, args);
	}

}
